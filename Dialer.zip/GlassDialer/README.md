# Glass Dialer

A full Android phone dialer (Kotlin + Jetpack Compose) with an Apple "liquid glass" look.

## Run it
1. Open this folder in **Android Studio** (Koala or newer) and let Gradle sync.
2. Run on a **real phone** (an emulator can't place real calls).
3. Grant the permissions, then tap the banner **"Make Glass Dialer your default phone app"**.
   Being the default dialer is what lets it handle incoming/outgoing calls, block numbers, and answer `tel:` links.

## Features
- Keypad: DTMF tones + haptics, smart T9 contact search, number formatting, paste (long-press number), long-press 0 = `+`, long-press 1 = voicemail, redial last number, USSD codes (`*#06#`), dual-SIM chooser
- Recents: all/missed filter, grouped repeats, call/message/copy/block/delete/add-to-contacts
- Contacts: A–Z list, search by name or number, star favorites, open in Contacts, new contact
- Favorites: glass tile grid, tap to call
- In-call: mute, keypad (DTMF), speaker/earpiece/Bluetooth/headset routing, hold/resume, add call, merge to conference, swap, call-waiting, timer
- Incoming call: full-screen lock-screen UI + heads-up notification with Answer/Decline; ongoing-call notification with Hang up
- Handles `ACTION_DIAL` / `tel:` intents from other apps

## Where things are
- `Glass.kt` – the glass toolkit (`Modifier.glass`, animated background, sheets, tab bar)
- `Screens.kt` – Keypad, Recents, Contacts, Favorites
- `Calls.kt` – `InCallService`, call state, notifications
- `InCall.kt` – in-call / incoming-call screen
- `Data.kt`, `Actions.kt` – contacts, call log, telecom helpers

## Notes
- Glass is drawn with translucent gradients, specular gloss and rim light over an animated backdrop. For true
  live backdrop blur of scrolling content, add the `dev.chrisbanes.haze` library.
- Visual voicemail and video calling are not included (they need carrier-specific services).

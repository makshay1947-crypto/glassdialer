package com.glassdialer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.widget.Toast

object Actions {
    private fun tm(ctx: Context) = ctx.getSystemService(TelecomManager::class.java)

    fun simAccounts(ctx: Context): List<PhoneAccountHandle> = try {
        val t = tm(ctx)
        t.callCapablePhoneAccounts.filter {
            t.getPhoneAccount(it)?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
        }
    } catch (_: SecurityException) {
        emptyList()
    }

    fun accountLabel(ctx: Context, h: PhoneAccountHandle): String =
        tm(ctx).getPhoneAccount(h)?.label?.toString() ?: "SIM"

    fun call(ctx: Context, number: String, account: PhoneAccountHandle? = null) {
        if (number.isBlank()) return
        val extras = Bundle()
        if (account != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, account)
        try {
            tm(ctx).placeCall(Uri.fromParts("tel", number, null), extras)
        } catch (_: SecurityException) {
            Toast.makeText(ctx, "Phone permission required", Toast.LENGTH_SHORT).show()
        }
    }

    fun voicemail(ctx: Context) {
        try {
            tm(ctx).placeCall(Uri.fromParts("voicemail", "", null), Bundle())
        } catch (_: Exception) {
            Toast.makeText(ctx, "Voicemail unavailable", Toast.LENGTH_SHORT).show()
        }
    }

    fun sms(ctx: Context, number: String) {
        ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun addContact(ctx: Context, number: String?) {
        val i = Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!number.isNullOrBlank()) i.putExtra(ContactsContract.Intents.Insert.PHONE, number)
        ctx.startActivity(i)
    }

    fun copy(ctx: Context, text: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("number", text))
        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
    }
}

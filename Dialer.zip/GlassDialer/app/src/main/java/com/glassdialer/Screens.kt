package com.glassdialer

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.provider.CallLog
import android.provider.Settings
import android.telephony.PhoneNumberUtils
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallMade
import androidx.compose.material.icons.rounded.CallMissed
import androidx.compose.material.icons.rounded.CallReceived
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Voicemail
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Date
import java.util.Locale

val BarSpace = 104.dp

// ───────────────────────── Dial pad ─────────────────────────

private val KEYS = listOf(
    listOf('1' to "", '2' to "ABC", '3' to "DEF"),
    listOf('4' to "GHI", '5' to "JKL", '6' to "MNO"),
    listOf('7' to "PQRS", '8' to "TUV", '9' to "WXYZ"),
    listOf('*' to "", '0' to "+", '#' to ""),
)

@Composable
fun DialPad(
    modifier: Modifier = Modifier,
    keySize: Dp = 74.dp,
    onPress: (Char) -> Unit = {},
    onRelease: (Char) -> Unit = {},
    onTap: (Char) -> Unit = {},
    onLongPress: ((Char) -> Unit)? = null,
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        KEYS.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { (c, letters) -> DialKey(c, letters, keySize, onPress, onRelease, onTap, onLongPress) }
            }
        }
    }
}

@Composable
private fun DialKey(
    c: Char, letters: String, size: Dp,
    onPress: (Char) -> Unit, onRelease: (Char) -> Unit, onTap: (Char) -> Unit, onLongPress: ((Char) -> Unit)?,
) {
    var pressed by remember { mutableStateOf(false) }
    val press by rememberUpdatedState(onPress)
    val release by rememberUpdatedState(onRelease)
    val tap by rememberUpdatedState(onTap)
    val long by rememberUpdatedState(onLongPress)
    val hasLong = onLongPress != null
    Box(
        Modifier
            .size(size)
            .glass(CircleShape, fill = if (pressed) 0.42f else 0.13f)
            .pointerInput(c, hasLong) {
                val longHandler: ((Offset) -> Unit)? = if (hasLong) ({ _: Offset -> long?.invoke(c) }) else null
                detectTapGestures(
                    onPress = {
                        pressed = true
                        press(c)
                        tryAwaitRelease()
                        pressed = false
                        release(c)
                    },
                    onLongPress = longHandler,
                    onTap = { tap(c) },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(c.toString(), fontSize = 30.sp, fontWeight = FontWeight.Light)
            if (letters.isNotEmpty()) Text(letters, fontSize = 9.sp, letterSpacing = 2.sp, color = Color.White.copy(0.7f))
        }
    }
}

private fun ToneGenerator.dtmf(c: Char) {
    val t = when (c) {
        in '0'..'9' -> ToneGenerator.TONE_DTMF_0 + (c - '0')
        '*' -> ToneGenerator.TONE_DTMF_S
        '#' -> ToneGenerator.TONE_DTMF_P
        else -> return
    }
    startTone(t, 120)
}

// ───────────────────────── Keypad ─────────────────────────

@Composable
fun KeypadScreen(
    digits: String,
    onDigits: (String) -> Unit,
    contacts: List<Contact>,
    lastDialed: String?,
    onCall: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current
    val curDigits by rememberUpdatedState(digits)
    val curOnDigits by rememberUpdatedState(onDigits)
    val tone = remember { try { ToneGenerator(AudioManager.STREAM_DTMF, 70) } catch (_: Exception) { null } }
    DisposableEffect(Unit) { onDispose { tone?.release() } }
    val tonesOn = remember {
        Settings.System.getInt(ctx.contentResolver, Settings.System.DTMF_TONE_WHEN_DIALING, 1) == 1
    }
    val matches = remember(digits, contacts) {
        if (digits.length < 2) emptyList() else contacts.filter { matchesT9(it, digits) }.take(2)
    }
    val shown = remember(digits) {
        if (digits.length > 3 && digits.all { it.isDigit() || it == '+' })
            PhoneNumberUtils.formatNumber(digits, Locale.getDefault().country) ?: digits
        else digits
    }
    val fontSize = when {
        digits.length <= 11 -> 38.sp
        digits.length <= 15 -> 30.sp
        else -> 24.sp
    }

    Column(Modifier.fillMaxSize().padding(bottom = BarSpace), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            matches.forEach { c ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(16.dp), 0.12f)
                        .clickable { onDigits(c.number.filter { it.isDigit() || it == '+' }) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(c.name, 32.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(c.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(c.number, fontSize = 13.sp, color = Color.White.copy(0.6f))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            shown, fontSize = fontSize, fontWeight = FontWeight.Light, maxLines = 1, textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .height(56.dp)
                .wrapContentHeight(Alignment.CenterVertically)
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = {
                        val t = clipboard.getText()?.text.orEmpty().filter { ch -> ch.isDigit() || ch in "+*#" }
                        if (t.isNotEmpty()) curOnDigits(curDigits + t)
                    })
                },
        )
        Box(Modifier.height(28.dp), contentAlignment = Alignment.Center) {
            if (digits.isNotEmpty()) {
                Text("Add to contacts", color = GlassBlue, fontSize = 15.sp, modifier = Modifier.clickable { Actions.addContact(ctx, digits) })
            }
        }
        Spacer(Modifier.height(10.dp))
        DialPad(
            onPress = { c ->
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                if (tonesOn) tone?.dtmf(c)
            },
            onTap = { c -> onDigits(digits + c) },
            onLongPress = { c ->
                when (c) {
                    '0' -> onDigits(digits + "+")
                    '1' -> Actions.voicemail(ctx)
                    else -> onDigits(digits + c)
                }
            },
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(74.dp), Alignment.Center) {
                GlassIconButton(Icons.Rounded.Voicemail, "Voicemail", { Actions.voicemail(ctx) }, 52.dp)
            }
            Box(
                Modifier
                    .size(74.dp)
                    .glass(CircleShape, 0.70f, GlassGreen)
                    .clickable {
                        if (digits.isEmpty()) lastDialed?.let(onDigits) else onCall(digits)
                    },
                Alignment.Center,
            ) { Icon(Icons.Rounded.Call, "Call", Modifier.size(32.dp), tint = Color.White) }
            Box(
                Modifier
                    .size(74.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { curOnDigits(curDigits.dropLast(1)) },
                            onLongPress = { curOnDigits("") },
                        )
                    },
                Alignment.Center,
            ) {
                if (digits.isNotEmpty()) Icon(Icons.Rounded.Backspace, "Delete", Modifier.size(28.dp), tint = Color.White.copy(0.85f))
            }
        }
    }
}

// ───────────────────────── Recents ─────────────────────────

fun formatWhen(ctx: Context, ms: Long): String {
    val now = System.currentTimeMillis()
    return when {
        DateUtils.isToday(ms) -> DateFormat.getTimeFormat(ctx).format(Date(ms))
        DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
        now - ms < 7 * DateUtils.DAY_IN_MILLIS -> DateUtils.formatDateTime(ctx, ms, DateUtils.FORMAT_SHOW_WEEKDAY)
        else -> DateFormat.getMediumDateFormat(ctx).format(Date(ms))
    }
}

private fun typeLabel(e: CallLogEntry): String {
    val base = when (e.type) {
        CallLog.Calls.INCOMING_TYPE -> "Incoming"
        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
        CallLog.Calls.MISSED_TYPE -> "Missed"
        CallLog.Calls.VOICEMAIL_TYPE -> "Voicemail"
        CallLog.Calls.REJECTED_TYPE -> "Declined"
        CallLog.Calls.BLOCKED_TYPE -> "Blocked"
        else -> "Call"
    }
    val d = e.duration
    return if (d > 0) "$base · ${if (d >= 60) "${d / 60} min ${d % 60} s" else "$d s"}" else base
}

@Composable
fun RecentsScreen(
    recents: List<CallLogEntry>,
    onCall: (String) -> Unit,
    onInfo: (RecentRow) -> Unit,
) {
    val ctx = LocalContext.current
    var missedOnly by remember { mutableStateOf(false) }
    val rows = remember(recents, missedOnly) { groupRecents(if (missedOnly) recents.filter { it.isMissed } else recents) }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Recents") { GlassIconButton(Icons.Rounded.Voicemail, "Voicemail", { Actions.voicemail(ctx) }) }
        Row(
            Modifier.padding(horizontal = 24.dp, vertical = 6.dp).fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.14f).padding(4.dp),
        ) {
            listOf("All" to false, "Missed" to true).forEach { (label, flag) ->
                val sel = missedOnly == flag
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (sel) Color.White.copy(0.26f) else Color.Transparent)
                        .clickable { missedOnly = flag }
                        .padding(vertical = 8.dp),
                    Alignment.Center,
                ) { Text(label, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal) }
            }
        }
        if (rows.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No recent calls", color = Color.White.copy(0.6f)) }
        }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = BarSpace),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(rows, key = { it.first.id }) { r ->
                val e = r.first
                val missed = e.isMissed
                val title = (e.name ?: e.number.ifBlank { "Unknown" }) + if (r.count > 1) " (${r.count})" else ""
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(22.dp))
                        .clickable { onCall(e.number) }
                        .padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        when {
                            missed -> Icons.Rounded.CallMissed
                            e.isOutgoing -> Icons.Rounded.CallMade
                            e.type == CallLog.Calls.INCOMING_TYPE -> Icons.Rounded.CallReceived
                            else -> Icons.Rounded.Block
                        },
                        null, Modifier.size(20.dp), tint = if (missed) GlassRed else Color.White.copy(0.7f),
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, fontSize = 17.sp, color = if (missed) GlassRed else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(typeLabel(e), fontSize = 13.sp, color = Color.White.copy(0.6f))
                    }
                    Text(formatWhen(ctx, e.date), fontSize = 13.sp, color = Color.White.copy(0.6f))
                    IconButton(onClick = { onInfo(r) }) { Icon(Icons.Rounded.Info, "Details", tint = GlassBlue) }
                }
            }
        }
    }
}


// ───────────────────────── Contacts ─────────────────────────

@Composable
fun GlassSearchField(value: String, onValue: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.14f).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, Modifier.size(20.dp), tint = Color.White.copy(0.6f))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, color = Color.White.copy(0.5f), fontSize = 17.sp)
            BasicTextField(
                value, onValue, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (value.isNotEmpty()) {
            Icon(Icons.Rounded.Close, "Clear", Modifier.size(20.dp).clickable { onValue("") }, tint = Color.White.copy(0.7f))
        }
    }
}

@Composable
fun ContactsScreen(contacts: List<Contact>, onOpen: (Contact) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val grouped = remember(contacts, q) {
        val qd = q.filter { it.isDigit() }
        val list = if (q.isBlank()) contacts else contacts.filter {
            it.name.contains(q, true) || (qd.isNotEmpty() && it.number.filter { ch -> ch.isDigit() }.contains(qd))
        }
        list.groupBy { c -> c.name.firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar() ?: '#' }
            .toSortedMap(compareBy<Char> { if (it == '#') '\uFFFF' else it })
    }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Contacts") { GlassIconButton(Icons.Rounded.PersonAdd, "New contact", { Actions.addContact(ctx, null) }) }
        GlassSearchField(q, { q = it }, "Search", Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = BarSpace),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            grouped.forEach { (letter, list) ->
                item(key = "h$letter") {
                    Text(letter.toString(), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(0.6f), modifier = Modifier.padding(start = 10.dp, top = 8.dp))
                }
                items(list, key = { "${it.id}:${it.number}" }) { c ->
                    Row(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp), 0.10f).clickable { onOpen(c) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(c.name, 42.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(c.number, fontSize = 13.sp, color = Color.White.copy(0.6f))
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Favorites ─────────────────────────

@Composable
fun FavoritesScreen(favorites: List<Contact>, onCall: (String) -> Unit, onInfo: (Contact) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Favorites") { GlassIconButton(Icons.Rounded.PersonAdd, "New contact", { Actions.addContact(ctx, null) }) }
        if (favorites.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("Star a contact to see it here", color = Color.White.copy(0.6f))
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = BarSpace),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(favorites, key = { "${it.id}:${it.number}" }) { c ->
                Box(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), 0.14f).clickable { onCall(c.number) }) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 22.dp, horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Avatar(c.name, 68.dp)
                        Spacer(Modifier.height(10.dp))
                        Text(c.name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(c.number, fontSize = 12.sp, color = Color.White.copy(0.6f), maxLines = 1)
                    }
                    IconButton(onClick = { onInfo(c) }, modifier = Modifier.align(Alignment.TopEnd)) {
                        Icon(Icons.Rounded.Info, "Details", Modifier.size(20.dp), tint = GlassBlue)
                    }
                }
            }
        }
    }
}

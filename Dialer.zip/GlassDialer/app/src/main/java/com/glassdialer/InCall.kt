package com.glassdialer

import android.content.Intent
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BluetoothAudio
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.CallMerge
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.Headset
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SwapCalls
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class InCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        setContent { GlassTheme { InCallScreen(onFinish = { finishAndRemoveTask() }) } }
    }
}

private fun stateLabel(s: Int) = when (s) {
    Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_PULLING_CALL -> "Calling…"
    Call.STATE_RINGING -> "Incoming call"
    Call.STATE_HOLDING -> "On hold"
    Call.STATE_DISCONNECTING -> "Ending…"
    Call.STATE_DISCONNECTED -> "Call ended"
    else -> ""
}

private fun labelOf(c: CallUi) = when {
    c.isConference -> "Conference call"
    else -> c.name ?: c.number.ifBlank { "Unknown" }
}

private fun fmt(sec: Long) =
    if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60)
    else "%02d:%02d".format(sec / 60, sec % 60)

@Composable
private fun CallTimer(connectTime: Long) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(500) } }
    Text(fmt(((now - connectTime) / 1000).coerceAtLeast(0)), fontSize = 18.sp, color = Color.White.copy(0.75f))
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val calls by CallManager.calls.collectAsState()
    val audio by CallManager.audio.collectAsState()
    var last by remember { mutableStateOf<List<CallUi>>(emptyList()) }
    var showPad by remember { mutableStateOf(false) }
    var dtmf by remember { mutableStateOf("") }

    LaunchedEffect(calls) {
        if (calls.isNotEmpty()) last = calls else { delay(900); onFinish() }
    }
    val ended = calls.isEmpty()
    val list = if (ended) last else calls
    val p = CallManager.primary(list)
    val others = list.filter { it !== p }

    GlassBackground {
        if (p != null) Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            others.forEach { o ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(20.dp), 0.16f)
                        .clickable(enabled = !ended) { o.call.unhold() }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.SwapCalls, null)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(labelOf(o), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(stateLabel(o.state), fontSize = 12.sp, color = Color.White.copy(0.6f))
                    }
                    Text("Swap", fontWeight = FontWeight.SemiBold, color = GlassBlue)
                }
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(24.dp))
            val title = labelOf(p)
            Avatar(title, 96.dp)
            Spacer(Modifier.height(16.dp))
            Text(title, fontSize = 34.sp, fontWeight = FontWeight.Light, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            if (p.name != null && p.number.isNotBlank()) Text(p.number, fontSize = 15.sp, color = Color.White.copy(0.6f))
            Spacer(Modifier.height(6.dp))
            if (!ended && p.state == Call.STATE_ACTIVE && p.connectTime > 0) CallTimer(p.connectTime)
            else Text(if (ended) "Call ended" else stateLabel(p.state), fontSize = 18.sp, color = Color.White.copy(0.75f))

            Spacer(Modifier.weight(1f))

            if (showPad && !ended) {
                Text(dtmf, fontSize = 30.sp, fontWeight = FontWeight.Light, maxLines = 1, modifier = Modifier.height(44.dp))
                DialPad(
                    keySize = 66.dp,
                    onPress = { c -> p.call.playDtmfTone(c); dtmf += c },
                    onRelease = { p.call.stopDtmfTone() },
                )
                Spacer(Modifier.height(12.dp))
                Text("Hide", fontSize = 17.sp, color = GlassBlue, modifier = Modifier.clickable { showPad = false }.padding(8.dp))
            } else if (p.state != Call.STATE_RINGING) {
                val muted = audio?.isMuted == true
                val route = audio?.route ?: CallAudioState.ROUTE_EARPIECE
                val btAvail = ((audio?.supportedRouteMask ?: 0) and CallAudioState.ROUTE_BLUETOOTH) != 0
                val (audioIcon, audioLabel) = when (route) {
                    CallAudioState.ROUTE_SPEAKER -> Icons.Rounded.VolumeUp to "Speaker"
                    CallAudioState.ROUTE_BLUETOOTH -> Icons.Rounded.BluetoothAudio to "Bluetooth"
                    CallAudioState.ROUTE_WIRED_HEADSET -> Icons.Rounded.Headset to "Headset"
                    else -> Icons.Rounded.PhoneInTalk to "Phone"
                }
                val holding = p.state == Call.STATE_HOLDING
                val mergeTarget = others.firstOrNull()

                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                    GlassCircle(
                        if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic, "Mute", { CallManager.setMuted(!muted) },
                        fill = if (muted) 0.6f else 0.14f, iconTint = if (muted) Color.Black else Color.White,
                    )
                    GlassCircle(Icons.Rounded.Dialpad, "Keypad", { showPad = true })
                    GlassCircle(
                        audioIcon, audioLabel,
                        {
                            CallManager.setRoute(
                                when {
                                    route == CallAudioState.ROUTE_SPEAKER -> if (btAvail) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_OR_EARPIECE
                                    route == CallAudioState.ROUTE_BLUETOOTH -> CallAudioState.ROUTE_WIRED_OR_EARPIECE
                                    else -> CallAudioState.ROUTE_SPEAKER
                                }
                            )
                        },
                        fill = if (route == CallAudioState.ROUTE_SPEAKER) 0.6f else 0.14f,
                        iconTint = if (route == CallAudioState.ROUTE_SPEAKER) Color.Black else Color.White,
                    )
                }
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                    GlassCircle(Icons.Rounded.PersonAdd, "Add call", {
                        ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
                    GlassCircle(
                        if (holding) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                        if (holding) "Resume" else "Hold",
                        { if (holding) p.call.unhold() else p.call.hold() },
                        enabled = p.canHold || holding,
                        fill = if (holding) 0.6f else 0.14f,
                        iconTint = if (holding) Color.Black else Color.White,
                    )
                    GlassCircle(
                        Icons.Rounded.CallMerge, "Merge",
                        { if (p.canMerge && mergeTarget != null) p.call.conference(mergeTarget.call) },
                        enabled = mergeTarget != null && p.canMerge,
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            if (p.state == Call.STATE_RINGING && !ended) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                    GlassCircle(Icons.Rounded.CallEnd, "Decline", { p.call.reject(false, null) }, diameter = 78.dp, fill = 0.75f, tint = GlassRed)
                    GlassCircle(Icons.Rounded.Phone, "Answer", { p.call.answer(VideoProfile.STATE_AUDIO_ONLY) }, diameter = 78.dp, fill = 0.75f, tint = GlassGreen)
                }
            } else {
                GlassCircle(Icons.Rounded.CallEnd, null, { p.call.disconnect() }, diameter = 78.dp, fill = 0.75f, tint = GlassRed, enabled = !ended)
            }
        }
    }
}

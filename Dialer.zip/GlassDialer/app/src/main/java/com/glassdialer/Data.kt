package com.glassdialer

import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Contact(val id: Long, val lookupKey: String, val name: String, val number: String, val starred: Boolean)

data class CallLogEntry(
    val id: Long, val number: String, val name: String?, val type: Int, val date: Long, val duration: Long,
) {
    val isMissed get() = type == CallLog.Calls.MISSED_TYPE
    val isOutgoing get() = type == CallLog.Calls.OUTGOING_TYPE
}

data class RecentRow(val first: CallLogEntry, val ids: List<Long>, val count: Int)

fun digitsKey(n: String) = n.filter { it.isDigit() }.takeLast(9)

fun groupRecents(list: List<CallLogEntry>): List<RecentRow> {
    val out = mutableListOf<RecentRow>()
    for (e in list) {
        val last = out.lastOrNull()
        if (last != null && last.first.number == e.number &&
            last.first.isMissed == e.isMissed && last.first.isOutgoing == e.isOutgoing
        ) {
            out[out.lastIndex] = last.copy(ids = last.ids + e.id, count = last.count + 1)
        } else out += RecentRow(e, listOf(e.id), 1)
    }
    return out
}

private fun t9(s: String): String = buildString {
    for (ch in s.lowercase()) append(
        when (ch) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> ch
            else -> ' '
        }
    )
}

/** Smart dial: matches word starts of the name (T9) or any part of the number. */
fun matchesT9(c: Contact, q: String): Boolean {
    val name9 = t9(c.name)
    if (name9.split(' ').any { it.isNotEmpty() && it.startsWith(q) }) return true
    if (name9.replace(" ", "").startsWith(q)) return true
    val qd = q.filter { it.isDigit() }
    return qd.isNotEmpty() && c.number.filter { it.isDigit() }.contains(qd)
}

object Repo {
    fun contacts(ctx: Context): List<Contact> {
        val out = mutableListOf<Contact>()
        val seen = HashSet<String>()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER, Phone.STARRED),
                null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val num = c.getString(3) ?: continue
                    if (!seen.add("$id:${num.filter { it.isDigit() }}")) continue
                    out += Contact(id, c.getString(1) ?: "", c.getString(2) ?: num, num, c.getInt(4) == 1)
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    fun callLog(ctx: Context, limit: Int = 300): List<CallLogEntry> {
        val out = mutableListOf<CallLogEntry>()
        try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION,
                ),
                null, null, "${CallLog.Calls.DATE} DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    out += CallLogEntry(c.getLong(0), c.getString(1) ?: "", c.getString(2), c.getInt(3), c.getLong(4), c.getLong(5))
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    fun deleteCallLog(ctx: Context, ids: List<Long>) {
        try {
            ids.forEach {
                ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "${CallLog.Calls._ID}=?", arrayOf(it.toString()))
            }
        } catch (_: Exception) {
        }
    }

    fun setStarred(ctx: Context, id: Long, starred: Boolean) {
        try {
            ctx.contentResolver.update(
                ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id),
                ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (starred) 1 else 0) },
                null, null,
            )
        } catch (_: Exception) {
        }
    }

    fun lookupName(ctx: Context, number: String): String? {
        if (number.isBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) {
            null
        }
    }

    /** Works only while this app is the default dialer. */
    fun block(ctx: Context, number: String): Boolean = try {
        val v = ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number) }
        ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v) != null
    } catch (_: Exception) {
        false
    }
}

class DialerViewModel(app: Application) : AndroidViewModel(app) {
    private val _contacts = MutableStateFlow<List<Contact>>(emptyList())
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()
    private val _recents = MutableStateFlow<List<CallLogEntry>>(emptyList())
    val recents: StateFlow<List<CallLogEntry>> = _recents.asStateFlow()

    private val ctx get() = getApplication<Application>()

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val cs = Repo.contacts(ctx)
            val names = HashMap<String, String>()
            cs.forEach { names.putIfAbsent(digitsKey(it.number), it.name) }
            val log = Repo.callLog(ctx).map { e ->
                e.copy(name = e.name?.takeIf { it.isNotBlank() } ?: names[digitsKey(e.number)])
            }
            _contacts.value = cs
            _recents.value = log
        }
    }

    fun deleteLog(ids: List<Long>) {
        viewModelScope.launch(Dispatchers.IO) { Repo.deleteCallLog(ctx, ids); refresh() }
    }

    fun setStarred(id: Long, starred: Boolean) {
        viewModelScope.launch(Dispatchers.IO) { Repo.setStarred(ctx, id, starred); refresh() }
    }

    fun block(number: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { Repo.block(ctx, number) }
            Toast.makeText(ctx, if (ok) "Number blocked" else "Set as default phone app to block numbers", Toast.LENGTH_SHORT).show()
        }
    }
}

package com.glassdialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Immutable snapshot of a telecom [Call] so Compose can observe changes. */
data class CallUi(
    val call: Call,
    val state: Int,
    val number: String,
    val name: String?,
    val connectTime: Long,
    val canHold: Boolean,
    val canMerge: Boolean,
    val canSwap: Boolean,
    val isConference: Boolean,
)

object CallManager {
    private val raw = mutableListOf<Call>()
    private val names = mutableMapOf<Call, String?>()
    private val _calls = MutableStateFlow<List<CallUi>>(emptyList())
    val calls: StateFlow<List<CallUi>> = _calls
    private val _audio = MutableStateFlow<CallAudioState?>(null)
    val audio: StateFlow<CallAudioState?> = _audio
    var service: InCallService? = null

    fun add(call: Call, name: String?) {
        if (call !in raw) raw += call
        names[call] = name
        refresh()
    }

    fun remove(call: Call) {
        raw -= call
        names -= call
        refresh()
    }

    fun refresh() {
        _calls.value = raw.filter { it.parent == null }.map { c ->
            val d = c.details
            CallUi(
                call = c,
                state = c.state,
                number = d.handle?.schemeSpecificPart.orEmpty(),
                name = names[c] ?: d.callerDisplayName?.takeIf { it.isNotBlank() },
                connectTime = d.connectTimeMillis,
                canHold = d.can(Call.Details.CAPABILITY_HOLD),
                canMerge = d.can(Call.Details.CAPABILITY_MERGE_CONFERENCE),
                canSwap = d.can(Call.Details.CAPABILITY_SWAP_CONFERENCE),
                isConference = d.hasProperty(Call.Details.PROPERTY_CONFERENCE),
            )
        }
    }

    fun onAudio(s: CallAudioState?) { _audio.value = s }

    fun primary(list: List<CallUi> = calls.value): CallUi? =
        list.firstOrNull { it.state == Call.STATE_RINGING }
            ?: list.firstOrNull { it.state == Call.STATE_ACTIVE || it.state == Call.STATE_DIALING || it.state == Call.STATE_CONNECTING }
            ?: list.firstOrNull()

    fun setMuted(m: Boolean) { service?.setMuted(m) }

    @Suppress("DEPRECATION")
    fun setRoute(route: Int) { service?.setAudioRoute(route) }
}

class CallService : InCallService() {
    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) { CallManager.refresh(); CallNotifications.update(this@CallService) }
        override fun onDetailsChanged(call: Call, details: Call.Details) { CallManager.refresh() }
        override fun onChildrenChanged(call: Call, children: MutableList<Call>) { CallManager.refresh() }
        override fun onParentChanged(call: Call, parent: Call?) { CallManager.refresh() }
    }

    @Suppress("DEPRECATION")
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.onAudio(callAudioState)
        call.registerCallback(cb)
        val number = call.details.handle?.schemeSpecificPart
        CallManager.add(call, number?.let { Repo.lookupName(this, it) })
        CallNotifications.update(this)
        // Ringing calls surface through the full-screen-intent notification; others open directly.
        if (call.state != Call.STATE_RINGING) {
            try {
                startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(cb)
        CallManager.remove(call)
        CallNotifications.update(this)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        CallManager.onAudio(audioState)
    }
}

object CallNotifications {
    private const val CHANNEL = "calls"
    private const val ID = 4242
    const val ACTION_ANSWER = "com.glassdialer.ANSWER"
    const val ACTION_DECLINE = "com.glassdialer.DECLINE"
    const val ACTION_HANGUP = "com.glassdialer.HANGUP"

    fun update(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val p = CallManager.primary()
        if (p == null) { nm.cancel(ID); return }

        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Calls", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null); enableVibration(false)
            }
        )
        val ringing = p.state == Call.STATE_RINGING
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags,
        )
        fun act(action: String, label: String, req: Int) = NotificationCompat.Action(
            0, label,
            PendingIntent.getBroadcast(ctx, req, Intent(ctx, CallActionReceiver::class.java).setAction(action), flags),
        )

        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(p.name ?: p.number.ifBlank { "Unknown" })
            .setContentText(
                when {
                    ringing -> "Incoming call"
                    p.state == Call.STATE_HOLDING -> "On hold"
                    else -> "Ongoing call"
                }
            )
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (ringing) {
            b.setFullScreenIntent(open, true)
                .addAction(act(ACTION_DECLINE, "Decline", 1))
                .addAction(act(ACTION_ANSWER, "Answer", 2))
        } else {
            b.addAction(act(ACTION_HANGUP, "Hang up", 3))
            if (p.state == Call.STATE_ACTIVE && p.connectTime > 0) b.setUsesChronometer(true).setWhen(p.connectTime)
        }
        try { nm.notify(ID, b.build()) } catch (_: SecurityException) {}
    }
}

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = CallManager.primary() ?: return
        when (intent.action) {
            CallNotifications.ACTION_ANSWER -> p.call.answer(VideoProfile.STATE_AUDIO_ONLY)
            CallNotifications.ACTION_DECLINE -> p.call.reject(false, null)
            CallNotifications.ACTION_HANGUP -> p.call.disconnect()
        }
    }
}

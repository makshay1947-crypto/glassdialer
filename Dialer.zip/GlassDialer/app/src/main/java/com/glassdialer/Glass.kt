package com.glassdialer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

val GlassGreen = Color(0xFF34C759)
val GlassRed = Color(0xFFFF453A)
val GlassBlue = Color(0xFF7FB2FF)

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Color.White)) {
        CompositionLocalProvider(LocalContentColor provides Color.White, content = content)
    }
}

/** The core "liquid glass" surface: translucent tint, top specular gloss, gradient rim light. */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(28.dp),
    fill: Float = 0.12f,
    tint: Color = Color.White,
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                tint.copy(alpha = (fill + 0.10f).coerceAtMost(1f)),
                tint.copy(alpha = fill),
            )
        ),
        shape,
    )
    .drawBehind {
        drawRect(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.20f), Color.Transparent),
                endY = size.height * 0.55f,
            ),
            size = Size(size.width, size.height * 0.55f),
        )
    }
    .border(
        0.8.dp,
        Brush.linearGradient(
            listOf(Color.White.copy(0.70f), Color.White.copy(0.06f), Color.White.copy(0.32f))
        ),
        shape,
    )

/** Slowly drifting colour blobs behind everything so the glass has something to refract. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(15000, easing = LinearEasing), RepeatMode.Reverse), label = "a"
    )
    val b by t.animateFloat(
        1f, 0f, infiniteRepeatable(tween(21000, easing = LinearEasing), RepeatMode.Reverse), label = "b"
    )
    Box(
        modifier
            .fillMaxSize()
            .background(Color(0xFF070A1C))
            .drawBehind {
                val w = size.width
                val h = size.height
                fun blob(c: Color, cx: Float, cy: Float, r: Float) {
                    drawCircle(
                        Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r),
                        radius = r,
                        center = Offset(cx, cy),
                    )
                }
                blob(Color(0xFF6A5CFF).copy(0.80f), w * (0.10f + 0.60f * a), h * (0.12f + 0.12f * b), w * 0.95f)
                blob(Color(0xFF00C2C7).copy(0.55f), w * (0.90f - 0.55f * b), h * (0.45f + 0.10f * a), w * 0.85f)
                blob(Color(0xFFFF4FA3).copy(0.55f), w * (0.20f + 0.40f * b), h * (0.90f - 0.15f * a), w * 0.90f)
            },
        content = content,
    )
}

@Composable
fun GlassCircle(
    icon: ImageVector,
    label: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    diameter: Dp = 72.dp,
    fill: Float = 0.14f,
    tint: Color = Color.White,
    iconTint: Color = Color.White,
    enabled: Boolean = true,
) {
    Column(modifier.alpha(if (enabled) 1f else 0.4f), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(diameter)
                .glass(CircleShape, fill, tint)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, label, Modifier.size(diameter * 0.4f), tint = iconTint)
        }
        if (label != null) {
            Text(label, fontSize = 12.sp, color = Color.White.copy(0.85f), modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun GlassIconButton(icon: ImageVector, desc: String, onClick: () -> Unit, size: Dp = 44.dp) {
    Box(
        Modifier.size(size).glass(CircleShape, 0.16f).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(22.dp)) }
}

@Composable
fun GlassTabBar(
    tabs: List<Pair<String, ImageVector>>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .glass(RoundedCornerShape(36.dp), fill = 0.20f)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        tabs.forEachIndexed { i, (label, icon) ->
            val sel = i == selected
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(30.dp))
                    .background(if (sel) Color.White.copy(0.24f) else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(icon, label, Modifier.size(24.dp), tint = if (sel) Color.White else Color.White.copy(0.6f))
                Text(
                    label, fontSize = 11.sp,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (sel) Color.White else Color.White.copy(0.6f),
                )
            }
        }
    }
}

@Composable
fun GlassSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(0.45f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
        )
    }
    AnimatedVisibility(
        visible,
        modifier = Modifier.fillMaxSize(),
        enter = slideInVertically { it },
        exit = slideOutVertically { it },
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(32.dp), fill = 0.24f, tint = Color(0xFFBFC8FF))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .padding(18.dp),
                content = content,
            )
        }
    }
}

@Composable
fun SheetHeader(title: String, subtitle: String?) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(title, 52.dp)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 14.sp, color = Color.White.copy(0.65f))
        }
    }
}

@Composable
fun SheetAction(icon: ImageVector, label: String, color: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color)
        Spacer(Modifier.width(14.dp))
        Text(label, fontSize = 17.sp, color = color)
    }
}

fun initialsOf(name: String): String =
    name.split(' ').filter { it.isNotBlank() }.take(2)
        .map { it.first().uppercaseChar() }.filter { it.isLetter() }.joinToString("")

@Composable
fun Avatar(name: String, size: Dp = 44.dp) {
    val hue = abs(name.hashCode() % 360).toFloat()
    val initials = initialsOf(name)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color.hsv(hue, 0.45f, 0.95f), Color.hsv((hue + 40f) % 360f, 0.65f, 0.72f)))),
        contentAlignment = Alignment.Center,
    ) {
        if (initials.isEmpty()) Icon(Icons.Rounded.Person, null, Modifier.size(size * 0.55f), tint = Color.White)
        else Text(initials, fontSize = (size.value * 0.38f).sp, fontWeight = FontWeight.SemiBold, color = Color.White, textAlign = TextAlign.Center)
    }
}

@Composable
fun ScreenTitle(title: String, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = 24.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}

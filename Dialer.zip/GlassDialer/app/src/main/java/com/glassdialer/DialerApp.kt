package com.glassdialer

import android.content.Intent
import android.provider.ContactsContract
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.Message
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.SimCard
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed interface Sheet {
    data class Sim(val number: String) : Sheet
    data class ContactInfo(val contact: Contact) : Sheet
    data class RecentInfo(val row: RecentRow) : Sheet
}

enum class Tab(val label: String, val icon: ImageVector) {
    Favorites("Favorites", Icons.Rounded.Star),
    Recents("Recents", Icons.Rounded.AccessTime),
    Contacts("Contacts", Icons.Rounded.Contacts),
    Keypad("Keypad", Icons.Rounded.Dialpad),
}

@Composable
fun DialerApp(
    vm: DialerViewModel,
    isDefault: Boolean,
    onMakeDefault: () -> Unit,
    preset: String?,
    onPresetConsumed: () -> Unit,
) {
    val ctx = LocalContext.current
    val contacts by vm.contacts.collectAsState()
    val recents by vm.recents.collectAsState()
    var tab by rememberSaveable { mutableStateOf(Tab.Keypad) }
    var digits by rememberSaveable { mutableStateOf("") }
    var sheet by remember { mutableStateOf<Sheet?>(null) }
    var lastSheet by remember { mutableStateOf<Sheet?>(null) }

    LaunchedEffect(preset) {
        if (preset != null) { digits = preset; tab = Tab.Keypad; onPresetConsumed() }
    }
    LaunchedEffect(sheet) { if (sheet != null) lastSheet = sheet }

    val placeCall: (String) -> Unit = { n ->
        if (n.isNotBlank()) {
            if (Actions.simAccounts(ctx).size > 1) sheet = Sheet.Sim(n) else Actions.call(ctx, n)
        }
    }
    val lastDialed = remember(recents) { recents.firstOrNull { it.isOutgoing }?.number }
    val favorites = remember(contacts) { contacts.filter { it.starred }.distinctBy { it.id } }

    GlassBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (!isDefault) DefaultBanner(onMakeDefault)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Crossfade(tab, label = "tab") { t ->
                    when (t) {
                        Tab.Favorites -> FavoritesScreen(favorites, placeCall) { sheet = Sheet.ContactInfo(it) }
                        Tab.Recents -> RecentsScreen(recents, placeCall) { sheet = Sheet.RecentInfo(it) }
                        Tab.Contacts -> ContactsScreen(contacts) { sheet = Sheet.ContactInfo(it) }
                        Tab.Keypad -> KeypadScreen(digits, { digits = it }, contacts, lastDialed, placeCall)
                    }
                }
            }
        }
        GlassTabBar(
            Tab.entries.map { it.label to it.icon }, tab.ordinal, { tab = Tab.entries[it] },
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding(),
        )
        GlassSheet(sheet != null, { sheet = null }) {
            val s = sheet ?: lastSheet
            if (s != null) SheetContent(s, vm, placeCall) { sheet = null }
        }
    }
}

@Composable
private fun DefaultBanner(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .glass(RoundedCornerShape(20.dp), 0.16f, GlassBlue)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Call, null)
        Spacer(Modifier.width(10.dp))
        Text("Make Glass Dialer your default phone app", Modifier.weight(1f), fontSize = 14.sp)
        Text("Set", fontWeight = FontWeight.Bold, color = GlassBlue)
    }
}

@Composable
private fun SheetContent(sheet: Sheet, vm: DialerViewModel, placeCall: (String) -> Unit, dismiss: () -> Unit) {
    val ctx = LocalContext.current
    when (sheet) {
        is Sheet.Sim -> {
            Text("Call with", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
            Actions.simAccounts(ctx).forEach { h ->
                SheetAction(Icons.Rounded.SimCard, Actions.accountLabel(ctx, h)) {
                    dismiss(); Actions.call(ctx, sheet.number, h)
                }
            }
        }

        is Sheet.ContactInfo -> {
            val c = sheet.contact
            SheetHeader(c.name, c.number)
            SheetAction(Icons.Rounded.Call, "Call") { dismiss(); placeCall(c.number) }
            SheetAction(Icons.Rounded.Message, "Message") { dismiss(); Actions.sms(ctx, c.number) }
            SheetAction(
                if (c.starred) Icons.Rounded.StarBorder else Icons.Rounded.Star,
                if (c.starred) "Remove from favorites" else "Add to favorites",
            ) { dismiss(); vm.setStarred(c.id, !c.starred) }
            SheetAction(Icons.Rounded.OpenInNew, "Open in Contacts") {
                dismiss()
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.getLookupUri(c.id, c.lookupKey))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        is Sheet.RecentInfo -> {
            val e = sheet.row.first
            SheetHeader(e.name ?: e.number.ifBlank { "Unknown" }, if (e.name != null) e.number else null)
            if (e.number.isNotBlank()) {
                SheetAction(Icons.Rounded.Call, "Call") { dismiss(); placeCall(e.number) }
                SheetAction(Icons.Rounded.Message, "Message") { dismiss(); Actions.sms(ctx, e.number) }
                if (e.name == null) SheetAction(Icons.Rounded.PersonAdd, "Create new contact") { dismiss(); Actions.addContact(ctx, e.number) }
                SheetAction(Icons.Rounded.ContentCopy, "Copy number") { dismiss(); Actions.copy(ctx, e.number) }
                SheetAction(Icons.Rounded.Block, "Block caller", GlassRed) { dismiss(); vm.block(e.number) }
            }
            SheetAction(Icons.Rounded.Delete, "Delete from recents", GlassRed) { dismiss(); vm.deleteLog(sheet.row.ids) }
        }
    }
}
